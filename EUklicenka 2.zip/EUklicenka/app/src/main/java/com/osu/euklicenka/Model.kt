package com.osu.euklicenka

class Model(val title:String, val desc:String, val photo:Int )